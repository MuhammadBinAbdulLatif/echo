import ConversationView from '@/components/dashboard/conversations/conversation-view'
import React from 'react'

function page() {
  return (
   <ConversationView />
  )
}

export default page
