import React from 'react'

function page() {
  return (
    <div>
      Conversations
    </div>
  )
}

export default page
