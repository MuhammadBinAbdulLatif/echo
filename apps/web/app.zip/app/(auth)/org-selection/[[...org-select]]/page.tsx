import OrgSelectView from '@/components/auth/org-select-view'
import React from 'react'
function page() {
  return (
    <OrgSelectView />
  )
}

export default page
